﻿namespace SurvayBasket.Abstractions.Consts.cs
{
    public static class DefaultUser
    {
        public const string AdminId  = "01954439-8011-7cca-9a77-c5c56990be36";
        public const string AdminEmail  = "Admin@Survay-Basket.com";
        public const string AdminPassword  = "Pass@Word123";
        public const string AdminConcurrencyStamp  = "01954439-8011-7cca-9a77-c5c6e1328a61";
        public const string AdminSecurityStamp  = "01954439-8011-7cca-9a77-c5c75ebac097";

    }
}
