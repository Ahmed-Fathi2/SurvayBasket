﻿namespace SurvayBasket.Errors
{
    public class AnswerErrors
    {

        public static readonly Error IvalidAnswer = new Error(" IvalidAnswer ", " this answer is not a selected from Question answers .");
    }
}
