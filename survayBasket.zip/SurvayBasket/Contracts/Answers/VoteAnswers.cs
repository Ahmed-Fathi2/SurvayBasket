﻿namespace SurvayBasket.Contracts.Answers
{
    public record VoteAnswers
        (
            int QuestionId,
            int AnswerId


        );
    
}
