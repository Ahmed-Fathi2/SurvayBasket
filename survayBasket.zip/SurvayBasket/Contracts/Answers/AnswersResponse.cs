﻿namespace SurvayBasket.Contracts.Answers
{
    public record AnswersResponse
        (
            int id,
            string Content
        );
    
}
