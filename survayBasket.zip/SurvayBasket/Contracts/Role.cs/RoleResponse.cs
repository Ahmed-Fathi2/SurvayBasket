﻿namespace SurvayBasket.Contracts.Role.cs
{
    public record RoleResponse
    (
        string Id,
        string Name,
        bool IsDeleted
       

        );
}
