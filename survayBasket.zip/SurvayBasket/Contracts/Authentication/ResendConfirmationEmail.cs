﻿namespace SurvayBasket.Contracts.Authentication
{
    public record  ResendConfirmationEmail
      (
        
        string Email

      );          
}
