﻿namespace SurvayBasket.Contracts.Results.VoteResults
{
    public record AnswerOfQuestions(
     string QuestionContent,
     string AnswerContent
 );
}
