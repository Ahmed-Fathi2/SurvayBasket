﻿namespace SurvayBasket.Contracts.Results.NumOfSelectionPerEachAnswer
{
    public record VotePerAnswer
    (

        string AnswerContent,
        int count
    );
}
