﻿namespace SurvayBasket.Contracts.AccountProfile.cs
{
    public record UserProfileResponse
    (

        string FirstName ,
        string LastName ,
        string Email ,
        string UserName
 
    );
}
