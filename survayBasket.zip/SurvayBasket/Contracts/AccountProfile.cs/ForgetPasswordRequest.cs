﻿namespace SurvayBasket.Contracts.AccountProfile.cs
{
    public record ForgetPasswordRequest
    (
        
        string Email
        
        
    );
}
